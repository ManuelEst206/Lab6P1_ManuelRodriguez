/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab6p1_manuelrodriguez;

import java.util.Scanner;

/**
 *
 * @author manu_
 */
public class Lab6P1_ManuelRodriguez {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int option;
        
        do{
            System.out.println("======MENU======");
            System.out.println("1. Drunk Dazed");
            System.out.println("2. SubArrays Manual");
            System.out.println("3. Busqueda Lineal");
            System.out.println("4. Salir");
            System.out.println("================");
            System.out.print("Seleccione una opcion: ");
            option = scanner.nextInt();
            
            switch(option){
                case 1:
                    System.out.println("=DRUNK DAZED=");
                    break;
                case 2:
                    System.out.println("=SUBARRAYS MANUAL=");
                    break;
                case 3:
                    System.out.println("=BUSQUEDA LINEAL=");
                    break;
                case 4:
                    System.out.println("Eso es todo, terminando...");
                    break;
                default:
                    System.out.println("Invalido, intente de nuevo...");
                
            }
        }while(option!=4);
        
    }//fin del main
    
}// fin del lab
